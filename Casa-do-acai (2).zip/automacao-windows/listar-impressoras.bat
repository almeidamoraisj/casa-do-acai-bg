@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File printers.ps1
pause

Add-Type -AssemblyName System.Drawing
[System.Drawing.Printing.PrinterSettings]::InstalledPrinters

'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {kitchenTickets,printOrder}=require('../kitchen');
const record=()=>({id:'BG-TESTE1234567',phone:'5566999999999',body:'Cliente: Ana\n*2x Marmita da Casa (750ml) — R$ 80,00*\n*Sem Banana*\n*1x Copo Premium (600ml) — R$ 27,00*\n*TOTAL: R$ 107,00*\nForma de pagamento: Pix'});
test('guias seguem modelo limpo com quantidade, tamanho e retirada sem preços',()=>{
 const tickets=kitchenTickets(record());assert.equal(tickets.length,2);
 const text=tickets[0].flatMap(r=>r.cells||[]).join('\n');
 assert.match(text,/Marmita da Casa \(750ml\)/);assert.match(text,/x2/);assert.match(text,/Sem Banana/);
 assert.doesNotMatch(text,/INCLUSOS|R\$/);assert.match(text,/Data:/);
 assert.deepEqual(tickets[0][3].cells,['PRODUTO','QTD']);
});
test('retomada não reimprime comanda ou guias já enviadas',async()=>{
 const r=record(),calls=[];let fail=true;
 const options={config:{printerName:'principal',kitchenPrinterName:'cozinha'},save(){},async printLayout(rows,printer,font,id){calls.push([id,printer]);if(id==='kitchen-1'&&fail)throw Error('fila');}};
 await assert.rejects(printOrder(r,options));fail=false;await printOrder(r,options);
 assert.deepEqual(calls,[['receipt','principal'],['kitchen-0','cozinha'],['kitchen-1','cozinha'],['kitchen-1','cozinha']]);
});
test('rótulos da comanda em maiúsculas',()=>{
 const rows=require('../receipt').receiptRows(record());const text=rows.flatMap(r=>r.cells||[]).join('\n');
 for(const label of ['PEDIDO:','CLIENTE:','CONTATO:','FORMA DE PAGAMENTO:'])assert.ok(text.includes(label));
});
test('agrupa iguais e separa retirada diferente',()=>{
 const r=record();r.body='Cliente: Ana\n*1x Copo Verão (600ml) — R$ 27,00*\n*1x Copo Verão (600ml) — R$ 27,00*\n*1x Copo Verão (600ml) — R$ 27,00*\n*Sem Banana*\n*TOTAL: R$ 81,00*\nForma de pagamento: Pix';
 const t=kitchenTickets(r);assert.equal(t.length,2);assert.equal(t[0][5].cells[1],'x2');assert.equal(t[1][5].cells[1],'x1');
});

const {test}=require('node:test'),assert=require('node:assert/strict');
const {parseOrder}=require('../core'),{receiptRows,parseReceipt,formatPhone}=require('../receipt');
const body='*Casa do Açaí BG*\nPedido: BG-123456789ABC\n\nCliente: João\n\n*PRODUTOS*\n\n*2x Marmita Duplo Sabor — R$ 86,00*\nAdicionais em cada unidade:\n  + Leite em pó · R$ 3,00\n\n*1x Copo Verão (600ml) — R$ 27,00*\n\n*TOTAL: R$ 113,00*\nForma de pagamento: Pix\n\n📍 *LOCAL DE ENTREGA*\nEndereço: Rua X, 123\nLocalização: https://www.google.com/maps?q=-15,-52';
const record={...parseOrder(body),phone:'5566992600308'};
test('novo pedido reconhecido e quantidade determina valor unitário na impressão',()=>{assert.ok(record.id);const r=parseReceipt(record);assert.equal(r.items[0].qty,2);assert.equal(r.items[0].unit,43);assert.equal(r.items[0].total,86);assert.equal(r.items[0].extras[0].price,3);assert.equal(r.total,113);assert.equal(r.phone,'(66) 99260-0308');});
test('comanda tem cabeçalho, contato real e colunas do modelo',()=>{const rows=receiptRows(record);assert.equal(rows[0].align,'center');assert.ok(rows.some(r=>r.cells?.[0]==='CONTATO: (66) 99260-0308'));assert.deepEqual(rows.find(r=>r.cells?.[0]==='PRODUTO').cells,['PRODUTO','QTD','VALOR','TOTAL']);assert.ok(rows.some(r=>r.cells?.[0]==='MARMITA DUPLO SABOR'&&r.cells[1]==='2'&&r.cells[2]==='R$ 43,00'&&r.cells[3]==='R$ 86,00'));assert.ok(rows.some(r=>r.cells?.[0]==='TOTAL: R$ 113,00'&&r.bold));});
test('total inconsistente exige revisão',()=>{assert.throws(()=>parseReceipt({...record,body:body.replace('TOTAL: R$ 113,00','TOTAL: R$ 10,00')}),/inconsistente/);});
test('não confunde id LID com telefone',()=>{assert.equal(formatPhone(null),'Não disponibilizado pelo WhatsApp');});

test('retiradas do WhatsApp aparecem na impressão sem preço adicional',()=>{
 const r={...record,body:record.body.replace('Adicionais em cada unidade:', '*Sem Creme de Ninho*\nAdicionais em cada unidade:')};
 assert.deepEqual(parseReceipt(r).items[0].removed,['Creme de Ninho']);assert.ok(receiptRows(r).some(row=>row.cells?.[0]==='Sem Creme de Ninho'));
});
test('impressão calcula troco pelo total do pedido',()=>{
 const r={...record,body:record.body.replace('Forma de pagamento: Pix','Forma de pagamento: Dinheiro\nTroco para: R$ 200,00\nTroco: R$ 1,00')};
 assert.equal(parseReceipt(r).change,87);assert.ok(receiptRows(r).some(row=>row.cells?.[0]==='Troco: R$ 87,00'));
 assert.throws(()=>parseReceipt({...r,body:r.body.replace('Troco para: R$ 200,00','Troco para: R$ 100,00')}),/troco inconsistente/);
});

test('cabeçalho QTD tem espaço maior e não quebra linha',()=>{
 const rows=receiptRows(record);const header=rows.find(r=>r.cells?.[0]==='PRODUTO');const product=rows.find(r=>r.cells?.[0]==='MARMITA DUPLO SABOR');
 assert.equal(header.noWrap,true);assert.equal(header.columns[1],.12);assert.deepEqual(header.columns,product.columns);assert.equal(header.columns.reduce((a,b)=>a+b,0),1);
});

const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../../script.js'),'utf8');
function setup(respond){
 const elements=new Map(),el=id=>{if(!elements.has(id))elements.set(id,{value:'',textContent:'',innerHTML:'',checked:false,setAttribute(){},classList:{toggle(){}}});return elements.get(id)};
 let ticks=Date.now(),opened;class FakeDate extends Date{static now(){return ticks+=3000}}
 const context=vm.createContext({Date:FakeDate,URLSearchParams,AbortController,setTimeout:()=>1,clearTimeout(){},document:{getElementById:el,addEventListener(){}},window:{crypto:{randomUUID:()=> '12345678-abcd-1234-1234-123456789abc'},open:url=>opened=url},fetch:async url=>{const body=await respond(new URL(url));return {ok:true,json:async()=>body}}});
 const run=code=>vm.runInContext(code,context);run(source);run('deliveryMode="current";locationRequestId=1;deliveryLocation={latitude:-15.896,longitude:-52.274,accuracy:12}');return {run,el,message:()=>decodeURIComponent(opened.split('?text=')[1])};
}
test('cidade e bairro continuam automáticos mesmo sem rua no primeiro serviço',async()=>{
 const x=setup(url=>url.hostname==='api.bigdatacloud.net'?{city:'Barra do Garças',localityName:'São José',countryCode:'BR'}:{address:{county:'Barra do Garças'}});
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.el('deliveryCity').value,'Barra do Garças');assert.equal(x.run('selectedNeighborhood()'),'São José');assert.equal(x.run('deliveryFee()'),0);assert.equal(x.el('deliveryCorrection').hidden,true);assert.match(x.el('currentAddress').value,/São José/);
 x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('locationVerified').checked=true;x.run('addProduct(0);confirmOrder()');const message=x.message();assert.doesNotMatch(message,/Barra do Garças/);assert.match(message,/Taxa de entrega: GRÁTIS/);
});
test('fonte alternativa completa a região quando a primeira consulta falha',async()=>{
 const x=setup(url=>{if(url.hostname!=='api.bigdatacloud.net')throw Error('offline');return {city:'Aragarças',locality:'Centro',countryCode:'BR'}});
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('deliveryFee()'),13);x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('locationVerified').checked=true;x.run('addProduct(0);confirmOrder()');assert.match(x.message(),/Cidade: Aragarças/);assert.match(x.message(),/TOTAL: R\$ 53,00/);
});
test('a cidade não é usada como bairro e falhas não ficam no cache',async()=>{
 const x=setup(url=>url.hostname==='api.bigdatacloud.net'?{city:'Barra do Garças',locality:'Barra do Garças'}:{lat:-15.896,lon:-52.274,address:{road:'Rua X',city:'Barra do Garças'}});
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('selectedNeighborhood()'),'');assert.equal(x.run('deliveryFee()'),null);assert.equal(x.run('addressCache.size'),0);assert.equal(x.el('cartConfirmBtn').disabled,true);assert.match(x.el('addressStatus').textContent,/Tentar novamente/);
});
test('Pontal calcula taxa pela cidade mesmo sem bairro disponível',async()=>{
 const x=setup(()=>({address:{road:'Rua X',city:'Pontal do Araguaia'}}));await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('deliveryFee()'),10);
});
test('link personalizado preenche o contato na mensagem antes do envio',async()=>{
 const x=setup(()=>({address:{road:'Rua X',city:'Barra do Garças',suburb:'Centro'}}));
 x.run('window.location={search:"?contato=5566999999999"}');
 // Recarrega como se a página fosse aberta a partir do link da saudação.
 const elements=new Map(),el=id=>{if(!elements.has(id))elements.set(id,{value:'',innerHTML:'',classList:{toggle(){}}});return elements.get(id)};
 let opened;const context=vm.createContext({document:{getElementById:el,addEventListener(){}},window:{location:{search:'?contato=5566999999999'},crypto:{randomUUID:()=> '12345678-abcd-1234-1234-123456789abc'},open:url=>opened=url}});
 const run=c=>vm.runInContext(c,context);run(source);el('custName').value='Cliente';el('custPayment').value='Pix';el('custAddress').value='Rua X - Centro - Barra do Garças';run('deliveryMode="other";suggestCity("Barra do Garças");suggestNeighborhood("Centro");addProduct(0);confirmOrder()');const message=decodeURIComponent(opened.split('?text=')[1]);assert.match(message,/Cliente: Cliente\nContato: \(66\) 99999-9999/);assert.doesNotMatch(message,/Barra do Garças/);
});

test('Aragarças sem bairro libera envio e não consulta bairro próximo',async()=>{
 let calls=0;const x=setup(()=>{calls++;return {address:{road:'Avenida Ana Isabel Aguiar',city:'Aragarças'}}});
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(calls,1);assert.equal(x.run('deliveryFee()'),13);
 x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('locationVerified').checked=true;x.run('addProduct(0);updateConfirmState();confirmOrder()');assert.equal(x.el('cartConfirmBtn').disabled,false);assert.match(x.message(),/Taxa de entrega: R\$ 13,00/);assert.doesNotMatch(x.message(),/Bairro:/);
});
test('Jardim Sena Marques corresponde ao bairro gratuito informado pela loja',()=>{
 const x=setup(()=>({}));assert.equal(x.run('matchNeighborhood("Jardim Sena Marques")'),'Sena Marques');
});

test('retiradas ficam no item correto, não alteram preço e resetam após adicionar',()=>{
 const x=setup(()=>({}));
 const i=x.run('ITEMS.findIndex(p=>p.label==="Copo Felicidade (300ml)")');
 const j=x.run(`ITEMS[${i}].ingredients.indexOf('Chocoball')`);assert.ok(j>=0);
 x.run(`toggleIngredient(${i},${j});addProduct(${i})`);
 assert.equal(x.run('cart[0].removed[0]'),'Chocoball');assert.equal(x.run(`drafts[${i}].removed.length`),0);assert.equal(x.run('cart[0].price'),20);
 x.run(`addProduct(${i})`);assert.equal(x.run('cart.length'),2);assert.equal(x.run('cart[1].removed.length'),0);
});
test('retirar e recolocar é reversível e aparece no WhatsApp',()=>{
 const x=setup(()=>({}));x.run('toggleIngredient(0,0);toggleIngredient(0,0)');assert.equal(x.run('drafts[0].removed.length'),0);
 x.run('toggleIngredient(0,0);addProduct(0)');x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('custAddress').value='Rua X';x.run('deliveryMode="other";suggestCity("Aragarças");confirmOrder()');assert.match(x.message(),/\*Sem Sonho de Valsa\*/);
});
test('Google preenche bairro e cidade antes dos outros serviços',async()=>{
 const x=setup(()=>{throw Error('serviço alternativo não deve ser consultado');});
 x.run(`window.google={maps:{Geocoder:class {geocode(request,callback){callback([{address_components:[{long_name:'Rua José Manoel da Silva',types:['route']},{long_name:'Jardim Sena Marques',types:['sublocality_level_1']},{long_name:'Barra do Garças',types:['administrative_area_level_2']}]}],'OK')}}}}`);
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('selectedNeighborhood()'),'Sena Marques');assert.equal(x.run('deliveryFee()'),0);assert.match(x.el('currentAddress').value,/Rua José Manoel da Silva - Jardim Sena Marques - Barra do Garças/);
});
test('Google não mistura bairro de outro município',()=>{
 const x=setup(()=>({}));
 const r=x.run(`parseGoogleAddress([{address_components:[{long_name:'Aragarças',types:['administrative_area_level_2']},{long_name:'Rua X',types:['route']}]},{address_components:[{long_name:'Barra do Garças',types:['administrative_area_level_2']},{long_name:'São José',types:['neighborhood']}]}])`);
 assert.equal(r.city,'Aragarças');assert.equal(r.neighborhood,'');
});
test('mapa cadastral preenche Sena Marques e entrega grátis no ponto do exemplo',async()=>{
 const x=setup(()=>({address:{road:'Rua José Manoel da Silva',city:'Barra do Garças'}}));
 x.run(fs.readFileSync(path.join(__dirname,'../../bairros-referencia.js'),'utf8'));
 x.run('deliveryLocation={latitude:-15.895991,longitude:-52.274554,accuracy:25}');
 await x.run('fillLocationAddress(deliveryLocation,1)');
 assert.equal(x.run('selectedNeighborhood()'),'Sena Marques');assert.equal(x.run('deliveryFee()'),0);assert.match(x.el('addressStatus').textContent,/mapa cadastral/);
 x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('locationVerified').checked=true;x.run('addProduct(0);updateConfirmState();confirmOrder()');assert.equal(x.el('cartConfirmBtn').disabled,false);assert.match(x.message(),/Bairro: Sena Marques/);assert.match(x.message(),/Taxa de entrega: GRÁTIS/);
});
test('referências locais não substituem outro município nem ponto distante',()=>{
 const x=setup(()=>({}));x.run(fs.readFileSync(path.join(__dirname,'../../bairros-referencia.js'),'utf8'));
 assert.equal(x.run('mappedNeighborhood({latitude:-15.895991,longitude:-52.274554},"Aragarças")'),null);
 assert.equal(x.run('mappedNeighborhood({latitude:-16.5,longitude:-53},"Barra do Garças")'),null);
 assert.equal(x.run('mappedNeighborhood({latitude:NaN,longitude:0},"Barra do Garças")'),null);
});
test('mapa não troca bairro retornado pelo serviço de endereço',async()=>{
 const x=setup(()=>({address:{road:'Rua X',city:'Barra do Garças',suburb:'Centro'}}));x.run(fs.readFileSync(path.join(__dirname,'../../bairros-referencia.js'),'utf8'));
 x.run('deliveryLocation={latitude:-15.895991,longitude:-52.274554,accuracy:25}');await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('selectedNeighborhood()'),'Centro');assert.equal(x.run('deliveryFee()'),6);
});
test('Dinheiro mostra troco, inclui entrega no cálculo e valida valor',()=>{
 const x=setup(()=>({}));x.el('custName').value='Cliente';x.el('custPayment').value='Dinheiro';x.el('custAddress').value='Rua X';x.run('deliveryMode="other";suggestCity("Aragarças");addProduct(0)');
 x.el('custChange').value='100,00';x.run('updateConfirmState();confirmOrder()');assert.equal(x.el('cashChangePanel').hidden,false);assert.equal(x.el('cartConfirmBtn').disabled,false);assert.match(x.message(),/Troco para: R\$ 100,00\nTroco: R\$ 47,00/);
 x.el('custChange').value='40';x.run('updateConfirmState()');assert.equal(x.el('cartConfirmBtn').disabled,true);assert.match(x.el('cashChangeError').textContent,/53,00/);
 x.el('custChange').value='texto';assert.equal(x.run('cashChange().valid'),false);
 x.el('custChange').value='';x.run('updateConfirmState();confirmOrder()');assert.equal(x.el('cartConfirmBtn').disabled,false);assert.match(x.message(),/Troco: Não precisa/);
});
test('troco não aparece nem bloqueia confirmação com Pix',()=>{
 const x=setup(()=>({}));x.el('custName').value='Cliente';x.el('custPayment').value='Pix';x.el('custAddress').value='Rua X';x.el('custChange').value='inválido';x.run('deliveryMode="other";suggestCity("Aragarças");addProduct(0);updateConfirmState();confirmOrder()');assert.equal(x.el('cashChangePanel').hidden,true);assert.equal(x.el('cartConfirmBtn').disabled,false);assert.doesNotMatch(x.message(),/Troco/);
});
test('área Abel Lira da loja corrige bairro do provedor e do cache',async()=>{
 const x=setup(()=>({address:{road:'Rua Trinta e Oito',city:'Barra do Garças',suburb:'Outro bairro'}}));
 x.run(fs.readFileSync(path.join(__dirname,'../../bairros-referencia.js'),'utf8'));
 x.run('deliveryLocation={latitude:-15.8821196,longitude:-52.2978947};addressCache.set("-15.88212,-52.29789",{street:"Rua Trinta e Oito",city:"Barra do Garças",neighborhood:"Outro bairro"})');
 await x.run('fillLocationAddress(deliveryLocation,1)');assert.equal(x.run('selectedNeighborhood()'),'Abel Lira');assert.equal(x.run('deliveryFee()'),0);
 assert.equal(x.run('priorityNeighborhood(deliveryLocation,"Aragarças")'),null);
 assert.equal(x.run('priorityNeighborhood({latitude:-15.878,longitude:-52.297},"Barra do Garças")'),null);
 assert.equal(x.run('priorityNeighborhood({latitude:-15.881,longitude:-52.295},"Barra do Garças").name'),'Abel Lira');
});
test('Novo Horizonte corrige Vila São José entre a avenida e a BR sem invadir Palmares',async()=>{
 const x=setup(()=>({address:{road:'Avenida Castelo Branco',city:'Barra do Garças',suburb:'Vila São José'}}));
 x.run(fs.readFileSync(path.join(__dirname,'../../bairros-referencia.js'),'utf8'));
 x.run('deliveryLocation={latitude:-15.8738995,longitude:-52.3239423}');
 await x.run('fillLocationAddress(deliveryLocation,1)');
 assert.equal(x.run('selectedNeighborhood()'),'Novo Horizonte');assert.equal(x.run('deliveryFee()'),0);
 assert.equal(x.run('priorityNeighborhood({latitude:-15.876,longitude:-52.323},"Barra do Garças").name'),'Novo Horizonte');
 assert.equal(x.run('priorityNeighborhood({latitude:-15.8669752,longitude:-52.3245109},"Barra do Garças")'),null);
 assert.equal(x.run('priorityNeighborhood({latitude:-15.879,longitude:-52.323},"Barra do Garças")'),null);
 assert.equal(x.run('priorityNeighborhood(deliveryLocation,"Pontal do Araguaia")'),null);
});

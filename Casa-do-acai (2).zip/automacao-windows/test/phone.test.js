const {test}=require('node:test'),assert=require('node:assert/strict');
const {resolvePhone}=require('../phone');
test('contato consultado mesmo com falha na conversão LID',async()=>{
 const client={getContactLidAndPhone:async()=>{throw Error('falha');}};
 assert.equal(await resolvePhone(client,{from:'123@lid',getContact:async()=>({id:{_serialized:'5566999999999@c.us'}})}),'5566999999999');
});
test('LID nunca vira telefone',async()=>{
 assert.equal(await resolvePhone({getContactLidAndPhone:async()=>[]},{from:'123456789012@lid',getContact:async()=>({id:{_serialized:'123456789012@lid'},number:'123456789012'})}),null);
});
test('converte LID para numero real',async()=>{
 assert.equal(await resolvePhone({getContactLidAndPhone:async()=>[{lid:'123@lid',pn:'5566999999999@c.us'}]},{from:'123@lid'}),'5566999999999');
});
test('consulta contato da conversa quando contato da mensagem falha',async()=>{
 const client={getContactLidAndPhone:async()=>[]};
 assert.equal(await resolvePhone(client,{from:'123@lid',getContact:async()=>{throw Error('indisponível');},getChat:async()=>({getContact:async()=>({id:{_serialized:'5566999999999@c.us'}})})}),'5566999999999');
});
test('link diário inclui o telefone do remetente',()=>{
 const {personalizedGreeting}=require('../core');
 assert.equal(personalizedGreeting('Olá https://almeidamoraisj.github.io/casa-do-acai/','5566999999999'),'Olá https://almeidamoraisj.github.io/casa-do-acai/?contato=5566999999999');
 assert.equal(personalizedGreeting('Olá https://almeidamoraisj.github.io/casa-do-acai/',null),'Olá https://almeidamoraisj.github.io/casa-do-acai/');
});

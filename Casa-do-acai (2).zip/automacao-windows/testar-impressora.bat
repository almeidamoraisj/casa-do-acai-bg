@echo off
cd /d "%~dp0"
node app.js --print-test
pause

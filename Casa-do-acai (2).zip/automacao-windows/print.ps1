param([Parameter(Mandatory=$true)][string]$LayoutFile,[Parameter(Mandatory=$true)][string]$PrinterName,[double]$PaperWidthMm=80,[double]$FontSize=9)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web.Extensions
Add-Type -ReferencedAssemblies System.Drawing,System.Web.Extensions -TypeDefinition @'
using System;
using System.IO;
using System.Drawing;
using System.Drawing.Printing;
using System.Collections.Generic;
using System.Web.Script.Serialization;
public class ReceiptRow {
 public string[] cells {get;set;}
 public float[] columns {get;set;}
 public string rule {get;set;}
 public string align {get;set;}
 public bool bold {get;set;}
 public bool italic {get;set;}
 public bool noWrap {get;set;}
 public float size {get;set;}
 public float space {get;set;}
 public float indent {get;set;}
}
public class ReceiptPrinter {
 static Font FontFor(ReceiptRow row,double size) {
  FontStyle style=FontStyle.Regular;
  if(row.bold)style|=FontStyle.Bold;
  if(row.italic)style|=FontStyle.Italic;
  return new Font("Arial",(float)size*(row.size>0?row.size:1),style);
 }
 static Font FittedFont(Graphics g,ReceiptRow row,double size,float width) {
  var font=FontFor(row,size);
  if(!row.noWrap || row.cells==null)return font;
  float scale=1;
  for(int i=0;i<row.cells.Length;i++) {
   float available=Math.Max(10,width*(row.columns!=null?row.columns[i]:1)-3);
   float measured=g.MeasureString(row.cells[i]??"",font).Width;
   if(measured>available)scale=Math.Min(scale,available/measured);
  }
  if(scale<1) {
   var fitted=new Font(font.FontFamily,font.Size*scale*.98f,font.Style);
   font.Dispose();return fitted;
  }
  return font;
 }
 static float DrawRow(Graphics g,ReceiptRow row,double size,float x,float y,float width,bool draw) {
  if(row.rule!=null) {
   if(draw){g.DrawLine(Pens.Black,x,y+3,x+width,y+3);if(row.rule=="double")g.DrawLine(Pens.Black,x,y+6,x+width,y+6);}
   return row.rule=="double"?13:9;
  }
  if(row.cells==null)return 0;
  float indent=Math.Max(0,Math.Min(row.indent,width*.25f));x+=indent;width-=indent;
  using(var font=FittedFont(g,row,size,width))using(var format=new StringFormat()){
   if(row.noWrap)format.FormatFlags|=StringFormatFlags.NoWrap;
   format.Trimming=StringTrimming.None;
   float height=font.GetHeight(g),offset=0;
   for(int i=0;i<row.cells.Length;i++){
    float cellWidth=width*(row.columns!=null?row.columns[i]:1);
    float measured=g.MeasureString(row.cells[i]??"",font,new SizeF(Math.Max(10,cellWidth-3),10000),format).Height;
    height=Math.Max(height,measured);
   }
   if(draw)for(int i=0;i<row.cells.Length;i++){
    float cellWidth=width*(row.columns!=null?row.columns[i]:1);
    format.Alignment=row.align=="center"?StringAlignment.Center:row.align=="right"||i>0?StringAlignment.Far:StringAlignment.Near;
    g.DrawString(row.cells[i]??"",font,Brushes.Black,new RectangleF(x+offset,y,Math.Max(10,cellWidth-3),height+2),format);
    offset+=cellWidth;
   }
   return height+3+row.space;
  }
 }
 public static void Print(string file,string printer,double mm,double size){
  if(mm<50||mm>100||size<6||size>16)throw new ArgumentException("Largura/fonte invalida.");
  var rows=new JavaScriptSerializer().Deserialize<List<ReceiptRow>>(File.ReadAllText(file,System.Text.Encoding.UTF8));
  using(var doc=new PrintDocument()) {
   doc.PrinterSettings.PrinterName=printer;
   if(!doc.PrinterSettings.IsValid)throw new Exception("Impressora nao encontrada: "+printer);
   doc.PrintController=new StandardPrintController();doc.DocumentName="Comanda Casa do Acai BG";
   int paperWidth=(int)Math.Round(mm/25.4*100);
   float estimated=24;
   using(var bitmap=new Bitmap(1,1)){
    bitmap.SetResolution(100,100);
    using(var g=Graphics.FromImage(bitmap)){
    g.PageUnit=GraphicsUnit.Display;
    foreach(var row in rows)estimated+=DrawRow(g,row,size,0,0,paperWidth-24,false);
    }
   }
   // Mede o cupom antes de imprimir para evitar uma folha com grande sobra.
   int paperHeight=Math.Min(3000,Math.Max(250,(int)Math.Ceiling(estimated+30)));
   doc.DefaultPageSettings.PaperSize=new PaperSize("Comanda",paperWidth,paperHeight);
   doc.DefaultPageSettings.Margins=new Margins(12,12,12,12);
   int next=0;
   doc.PrintPage+=(sender,e)=>{
    float width=Math.Min(e.MarginBounds.Width,e.PageSettings.PrintableArea.Width-24);
    float y=e.MarginBounds.Top,bottom=Math.Min(e.MarginBounds.Bottom,e.PageSettings.PrintableArea.Bottom-12);
    if(width<80||bottom-y<40)throw new Exception("Area de impressao invalida. Confira o driver e papel.");
    while(next<rows.Count){
     float height=DrawRow(e.Graphics,rows[next],size,e.MarginBounds.Left,y,width,false);
     if(height>bottom-e.MarginBounds.Top)throw new Exception("Linha maior que a pagina. Reduza a fonte ou confira o pedido.");
     if(y+height>bottom)break;
     DrawRow(e.Graphics,rows[next],size,e.MarginBounds.Left,y,width,true);y+=height;next++;
    }
    e.HasMorePages=next<rows.Count;
   };
   doc.Print();
  }
 }
}
'@
try {[ReceiptPrinter]::Print($LayoutFile,$PrinterName,$PaperWidthMm,$FontSize);exit 0} catch {Write-Error $_;exit 1}

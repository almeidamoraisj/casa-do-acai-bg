'use strict';
const money=n=>'R$ '+n.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
const number=s=>Number(s.replaceAll('.','').replace(',','.'));
function formatPhone(phone){
  const digits=String(phone||'').replace(/\D/g,'');
  if(!digits)return 'Não disponibilizado pelo WhatsApp';
  const match=digits.match(/^55(\d{2})(\d{4,5})(\d{4})$/);
  return match?`(${match[1]}) ${match[2]}-${match[3]}`:'+'+digits;
}
function parseReceipt(record){
  const lines=record.body.replace(/\r/g,'').split('\n');
  const items=[];let current=null;
  for(let line of lines){
    line=line.trim();
    // Atual: quantidade + produto + subtotal, sem preço unitário no WhatsApp.
    let m=line.match(/^\*(\d+)x (.+) — R\$ ([\d.,]+)\*$/);
    if(!m)m=line.match(/^• (\d+)x (.+) — R\$ ([\d.,]+)$/);
    if(m){current={name:m[2],qty:Number(m[1]),total:number(m[3]),extras:[],removed:[]};current.unit=current.total/current.qty;items.push(current);continue;}
    // Layout anterior: título numerado e linha de quantidade/valor.
    m=line.match(/^\*\d+\. (.+)\*$/);
    if(m){current={name:m[1],extras:[],removed:[]};items.push(current);continue;}
    m=line.match(/^• (\d+)x · R\$ ([\d.,]+) cada · \*R\$ ([\d.,]+)\*$/);
    if(m&&current){current.qty=Number(m[1]);current.unit=number(m[2]);current.total=number(m[3]);continue;}
    const removal=line.match(/^\*?Sem (.+?)\*?$/i);
    if(removal&&current){(current.removed ||= []).push(removal[1]);continue;}
    m=line.match(/^\+ (.+) · R\$ ([\d.,]+)$/);
    if(m&&current){current.extras.push({name:m[1],price:number(m[2])});continue;}
    m=line.match(/^\+ (.+)$/);
    if(m&&current)current.extras.push({name:m[1],price:null});
  }
  const value=(pattern)=>{const m=record.body.match(pattern);return m?m[1].trim():'';};
  const totalString=value(/^\*?(?:TOTAL|Total|TOTAL DOS PRODUTOS): R\$ ([\d.,]+)\*?$/m);
  if(!items.length || items.some(i=>!Number.isFinite(i.total)||!Number.isFinite(i.unit)||!i.qty))throw Error('Não foi possível montar a comanda; confira o formato do pedido.');
  const total=number(totalString);
  const productsTotal=items.reduce((sum,i)=>sum+i.total,0);
  const feeString=value(/^Taxa de entrega: R\$ ([\d.,]+)$/m);
  const fee=feeString ? number(feeString) : 0;
  if(!Number.isFinite(total)||!Number.isFinite(fee)||fee<0||Math.abs(productsTotal+fee-total)>.02)throw Error('Total inconsistente. Confira o pedido antes de imprimir.');
  const payment=value(/^Forma de pagamento: (.+)$/m);
  const cashAmount=value(/^Troco para: R\$ ([\d.,]+)$/m);
  const changeFor=payment==='Dinheiro' && cashAmount ? number(cashAmount) : null;
  if(changeFor!==null && (!Number.isFinite(changeFor) || changeFor < total)) throw Error('Valor para troco inconsistente. Confira o pedido antes de imprimir.');
  const change=changeFor===null ? null : Math.round((changeFor-total)*100)/100;
  const noChange=payment==='Dinheiro' && /^Troco: Não precisa$/m.test(record.body);
  return {changeFor,change,noChange,productsTotal,fee,city:value(/^Cidade: (.+)$/m),feePending:record.body.includes('Taxa de entrega: a confirmar'),neighborhood:value(/^Bairro: (.+)$/m),id:record.id,client:value(/^(?:Cliente|Nome): (.+)$/m),phone:formatPhone(record.phone || (record.sender?.endsWith('@c.us') ? record.sender.split('@')[0] : null)),items,total,payment:value(/^Forma de pagamento: (.+)$/m),address:value(/^Endereço: (.+)$/m),complement:value(/^Complemento: (.+)$/m),note:value(/^Observação: (.+)$/m),location:value(/(?:Localização: )?(https:\/\/www\.google\.com\/maps\?q=[^\s]+)/)};
}
function receiptRows(record){
  const r=parseReceipt(record),rows=[];
  const text=(value,style={})=>rows.push({cells:[value],...style});
  const rule=(kind='solid')=>rows.push({rule:kind});
  text('Casa do Açaí BG',{bold:true,align:'center',size:1.18,space:8});rule('double');
  text('PEDIDO: '+r.id,{italic:true,space:8});text('CLIENTE: '+r.client,{bold:true});text('CONTATO: '+r.phone,{space:8});rule('double');
  rows.push({cells:['PRODUTO','QTD','VALOR','TOTAL'],columns:[.46,.12,.21,.21],bold:true,size:.85,noWrap:true});rule('double');
  for(const item of r.items){
    rows.push({cells:[item.name.toUpperCase(),String(item.qty),money(item.unit),money(item.total)],columns:[.46,.12,.21,.21],size:.85});
    for(const name of item.removed || [])rows.push({cells:['Sem '+name],size:.85,bold:true});
    for(const a of item.extras)rows.push({cells:['1x '+a.name,a.price===null?'':money(a.price)],columns:[.68,.32],size:.8});
    rule();
  }
  rule('double');text('Produtos: '+money(r.productsTotal),{bold:true,italic:true,align:'right'});
  text('Taxa de entrega: '+(r.feePending?'a confirmar':r.fee===0?'GRÁTIS':money(r.fee)),{bold:true,italic:true,align:'right'});
  rule('double');text((r.feePending?'TOTAL DOS PRODUTOS: ':'TOTAL: ')+money(r.total),{bold:true,italic:true,align:'right',size:1.25,space:12});
  text('FORMA DE PAGAMENTO: '+r.payment,{size:.9});
  if(r.changeFor!==null){text('Troco para: '+money(r.changeFor),{bold:true,size:.9});text('Troco: '+money(r.change),{bold:true,size:.9});}
  else if(r.noChange)text('Troco: Não precisa',{size:.9});
  text('Endereço: '+r.address,{size:.9});
  if(r.city && r.city !== 'Barra do Garças')text('Cidade: '+r.city,{size:.9});
  if(r.neighborhood)text('Bairro: '+r.neighborhood,{size:.9});
  if(r.complement)text('Complemento: '+r.complement,{size:.9});
  if(r.note)text('Observação: '+r.note,{size:.9});
  if(r.location)text('Localização: '+r.location,{size:.8});
  return rows;
}
module.exports={formatPhone,parseReceipt,receiptRows};

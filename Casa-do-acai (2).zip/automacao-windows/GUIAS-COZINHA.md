# Comanda e guias de cozinha

Atualize a pasta automacao-windows, preservando seu config.json e sua sessão. Feche o programa antes de atualizar e abra novamente depois. Não precisa alterar o site para esta atualização de impressão.

As guias são ativadas automaticamente mesmo com o config.json antigo. Cada configuração de produto gera um trabalho de impressão separado, depois da comanda. Produtos iguais são agrupados com quantidade; tamanhos, adicionais ou retiradas diferentes geram guias separadas. O layout segue o modelo enviado: cliente, data/hora de Brasília, colunas PRODUTO e QTD e modificações menores abaixo. Para reduzir a poluição, a receita padrão não é repetida: aparecem somente retiradas e adicionais, estes por unidade. Observações gerais aparecem em cada guia para não perder instruções de preparo.

No config.json, adicione opcionalmente (respeitando as vírgulas do JSON):

- "kitchenPrinterName": "nome exato da impressora da cozinha" — se vazio ou ausente, usa printerName, a mesma impressora da comanda.
- "kitchenFontSize": 10 — tamanho em pontos; o nome do produto usa negrito maior.
- "kitchenEnabled": false — somente se quiser desativar as guias.

Configure o driver Windows para cortar o papel ao final de cada trabalho. O corte e o tamanho mínimo do papel dependem do driver. Arial 9 é usada na comanda; Arial 10 nas guias. Confirme legibilidade e corte com uma impressão física na MP4200TH.

Execute o teste de impressão existente (--print-test): agora imprime a comanda e sua guia. O teste envia trabalhos reais à impressora configurada. Verifique a fila antes de repetir.

Se uma guia falhar, as etapas já enviadas ficam registradas. A repetição manual (--retry CODIGO) pula as etapas concluídas. Sucesso significa envio ao Windows, não confirmação física do papel; confira a fila em caso de falha ou interrupção. Não há repetição automática após erro.

As receitas estão em recipes.json. Ao mudar ingredientes do cardápio, atualize também esse arquivo antes de usar a automação. Receita desconhecida bloqueia a impressão e registra o erro, evitando uma guia incompleta.

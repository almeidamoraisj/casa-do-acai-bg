'use strict';
function phoneFromId(id) {
  const value = typeof id === 'string' ? id : id?._serialized;
  return /^\d{10,15}@c\.us$/.test(value || '') ? value.split('@')[0] : null;
}
async function resolvePhone(client, message) {
  const direct = phoneFromId(message.from);
  if (direct) return direct;
  // Uma falha no LID não deve impedir a consulta do contato.
  try {
    const pairs = await client.getContactLidAndPhone([message.from]);
    const pair = pairs.find(p => p.lid === message.from) || (pairs.length===1 ? pairs[0] : null);
    const phone = phoneFromId(pair?.pn);
    if (phone) return phone;
  } catch {}
  try {
    const contact = await message.getContact();
    const phone = phoneFromId(contact.id);
    if (phone) return phone;
    const id = contact.id?._serialized;
    if (id?.endsWith('@lid')) {
      const pairs = await client.getContactLidAndPhone([id]);
      const resolved = phoneFromId(pairs.find(p => p.lid === id)?.pn);
      if (resolved) return resolved;
    }
  } catch {}
  try {
    const chat=await message.getChat();
    const contact=await chat.getContact();
    const phone=phoneFromId(contact.id);
    if(phone)return phone;
  } catch {}
  try {
    const chat = await message.getChat();
    const contact = await chat.getContact();
    const phone = phoneFromId(contact.id);
    if (phone) return phone;
    const id = contact.id?._serialized;
    if (id?.endsWith('@lid')) {
      const pairs = await client.getContactLidAndPhone([id]);
      const resolved = phoneFromId(pairs.find(p => p.lid === id)?.pn);
      if (resolved) return resolved;
    }
  } catch {}
  return null;
}
module.exports = {resolvePhone, phoneFromId};

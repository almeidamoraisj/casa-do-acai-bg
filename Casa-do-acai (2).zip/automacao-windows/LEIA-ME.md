# Casa do Açaí BG — impressão e atendimento no Windows

O programa conecta o WhatsApp Business por QR Code. Ao receber a primeira mensagem de cada cliente no dia, responde:

> Boa Tarde, Casa do Açaí BG agradece seu contato, segue o link do nosso cardápio para realizar seu pedido: https://almeidamoraisj.github.io/casa-do-acai/

A contagem usa America/Sao_Paulo (Brasília) e reinicia à meia-noite. O registro fica salvo após fechar e abrir o programa. Grupos, status e mensagens enviadas pela própria loja são ignorados. Não desative essa resposta no config.json se quiser manter a função. Desative a saudação nativa do WhatsApp Business, caso esteja ativa, para não haver duas boas-vindas.

Pedidos com o cabeçalho compacto `Pedido BG-...` (ou o cabeçalho da versão anterior), gerado pelo cardápio atualizado, são enviados à impressora somente depois de a mensagem ser recebida no WhatsApp. Uma conversa comum não é impressa. Nome, pagamento, produtos, adicionais, valores e entrega constam no cupom. O cliente pode editar a mensagem: a impressão reproduz os dados recebidos, sem validar pagamento ou autenticidade do conteúdo.

## Instalação

1. Extraia o ZIP inteiro. Atualize os arquivos públicos `index.html`, `style.css` e `script.js` no seu GitHub Pages. Não publique a pasta de automação, dados ou sessão.
2. Instale o Node.js LTS (versão 22 ou superior) de https://nodejs.org no computador da loja. Esta etapa requer internet.
3. Instale a Bematech no Windows com o driver do fabricante. Primeiro confirme que ela imprime a página de teste do Windows.
4. Abra a pasta `automacao-windows` e dê dois cliques em `instalar.bat`. A instalação baixa a biblioteca e o navegador necessário. Aguarde a conclusão sem fechar a janela. Se houver erro, não continue até resolvê-lo.
5. Abra `listar-impressoras.bat`. Copie o nome EXATO da impressora.
6. Abra `config.json` no Bloco de Notas e substitua `"printerName": ""` por `"printerName": "nome exato da sua impressora"`. Salve. Não mude a estrutura JSON. `paperWidthMm` começa em 80: ajuste para 58 somente se esse for o papel/driver usado. FontSize pode variar de 6 a 16.
7. Com o programa fechado, abra `testar-impressora.bat`. Verifique largura, acentos, quebra de linhas, papel e corte. A configuração do corte depende do driver. O programa usa a fila do Windows; não depende de comandos ESC/POS específicos da T4200.
8. Abra `iniciar.bat`. No celular, vá a WhatsApp Business > Aparelhos conectados > Conectar aparelho e escaneie o QR Code exibido. O programa salva a sessão no computador.
9. Teste com outro celular: envie “Olá” (deve responder uma vez), envie outra mensagem (não deve responder novamente), depois envie um pedido pelo cardápio atualizado (deve imprimir). Um código já recebido não deve imprimir novamente.

A janela deve ficar aberta; computador, internet e impressora devem estar disponíveis. Não abra duas instâncias. O programa não foi instalado na sua máquina por este ZIP: os passos acima são necessários. Não há mensalidade de software/API, mas esta é uma conexão NÃO OFICIAL. Ela pode desconectar, quebrar após atualização e causar bloqueio da conta. A compatibilidade com sua impressora USB e o envio real precisam ser testados na loja.

## Operação e falhas

- `Ctrl+C` encerra o programa. Abra `iniciar.bat` novamente para reconectar.
- Os registros e a sessão ficam em `%LOCALAPPDATA%\CasaAcaiBG`. Eles incluem dados dos pedidos e credenciais da sessão: proteja o computador e não compartilhe essa pasta.
- “Enviado à fila da impressora” não garante que saiu papel. Confira a fila do Windows se faltar papel, cabo ou conexão. O spooler pode aguardar a impressora; não reimprima enquanto houver um trabalho pendente.
- Em caso de erro, o pedido permanece registrado. O programa não repete automaticamente uma impressão cujo resultado possa ser incerto.
- Abra um terminal na pasta e use `node app.js --list` com o programa fechado para listar os pedidos.
- Depois de conferir que NÃO existe trabalho impresso/pendente, use `node app.js --retry BG-CODIGO-DO-PEDIDO` para reenviar um pedido marcado com falha ou interrompido. Pedidos já submetidos à fila são recusados. Confirme manualmente que não houve impressão antes de repetir.
- Se o computador cair enquanto envia uma saudação, o envio pode ter acontecido. O programa não repete essa saudação no dia, mesmo se o registro estiver como “sending” ou “failed”. Isso prioriza não duplicar mensagens.
- A primeira mensagem considerada é a primeira recebida enquanto o programa estiver conectado. Mensagens recebidas quando ele está desligado/desconectado não têm impressão automática garantida; confira essas conversas manualmente ao voltar. Não há busca automática do histórico antigo.
- Se aparecer “Programa já aberto”, confira se existe outra instância. Após um encerramento inesperado e SOMENTE se não houver programa ativo, remova `%LOCALAPPDATA%\CasaAcaiBG\app.lock` e abra novamente.
- Não apague `state.json`: ele evita saudações e impressões duplicadas. Faça backup da pasta de dados com o programa fechado.

## Localização no cardápio

A captura busca várias leituras por até 30 segundos e mantém a de menor margem de erro. Encerra mais cedo se a precisão chegar a 30 metros ou melhor. O cliente deve conferir o link do mapa, informar o endereço e marcar a confirmação. Abaixo de boa precisão, o texto orienta usar endereço digitado. Isso não garante que o GPS esteja correto; permissão “localização precisa”, sinal e configurações do celular influenciam o resultado. HTTPS é obrigatório.

## Verificação deste pacote

Testes automatizados cobrem saudação por cliente/dia, meia-noite de Brasília, reinício, reconhecimento de pedidos, duplicação e falhas. Não foi possível testar QR Code, WhatsApp real ou impressão física no ambiente de preparação, que não é Windows.

## Endereço automático e pedido compacto

Depois da captura GPS, o cardápio consulta o Nominatim/OpenStreetMap para sugerir rua, número quando disponível, bairro e cidade. O cliente pode corrigir o campo e deve conferir o número. Se a consulta falhar, continua sendo possível digitar o endereço. A consulta é única por captura concluída, com cache local em memória e intervalo mínimo entre consultas; não há busca a cada tecla. O endpoint está na constante REVERSE_GEOCODE_URL em script.js e pode ser trocado. O serviço público tem limites de uso, não possui garantia de disponibilidade e requer respeitar https://operations.osmfoundation.org/policies/nominatim/. Para grande volume, use um serviço próprio ou provedor apropriado.

A mensagem agora mostra só código curto, produtos com subtotal, adicionais escolhidos sem repetir valores, total, cliente, pagamento e entrega. A observação aparece somente se preenchida. Atualize também core.js no programa Windows para reconhecer o novo cabeçalho; não apague os dados da sessão nem state.json.

## Layout e seleção de adicionais

O pedido usa cabeçalho Casa do Açaí BG, cliente, blocos por produto com quantidade, preço por unidade e subtotal, adicionais com preço, total destacado, pagamento e entrega. Cada adicional pode ser selecionado apenas uma vez por produto. Depois de adicionar ao carrinho, o rascunho é limpo e a quantidade volta a 1. Os produtos já adicionados são preservados. Atualize core.js junto com os arquivos públicos do site para reconhecer esse cabeçalho.

## Mensagem simplificada e impressão em colunas

A mensagem do cliente mostra quantidade, produto e subtotal na mesma linha, sem índice numérico e sem preço unitário. As marmitas não repetem 750ml; os copos mantêm o tamanho. Duplo Sabor não repete Açaí e Cupuaçu.

A impressão é diagramada independentemente do texto do WhatsApp, seguindo o modelo: cabeçalho centralizado, pedido, cliente e contato, divisórias, colunas PRODUTO/QTD/VALOR/TOTAL, adicionais sob cada produto, subtotal de produtos, total destacado, pagamento e entrega. Não é mais uma cópia da mensagem impressa como texto corrido. Uma taxa de entrega não é adicionada porque o site atual não calcula essa taxa; o valor de R$ 7,00 no exemplo não foi adotado.

O telefone real é identificado no recebimento pela automação. IDs @lid são resolvidos para número de telefone, quando o WhatsApp disponibiliza essa informação. Se não disponibilizar, a comanda informa isso, sem inventar um número. O site não pode obter o número da conta do cliente antes de enviar a mensagem, e a automação não altera o texto de mensagens recebidas. Assim, o contato automático é incluído na impressão, não na mensagem original do cliente.

Para atualizar: feche o programa, substitua app.js, core.js, print.ps1 e copie receipt.js e a pasta test desta versão. Preserve config.json com o nome de sua impressora, e não apague a sessão nem state.json. Rode testar-impressora.bat antes de iniciar.bat. A prévia de diagramação foi conferida; escala, corte e compatibilidade real ainda dependem do teste na Bematech/Windows.

## Taxas de entrega cadastradas

Barra do Garças: entrega grátis nos 19 bairros da lista; R$ 6,00 nos demais. Pontal do Araguaia: R$ 10,00 em qualquer bairro. Aragarças: R$ 13,00 em qualquer bairro. A cidade prevalece sobre o nome do bairro, e cidade/bairro precisam ser confirmados antes do envio. A sugestão de bairro por localização continua sujeita à conferência do cliente. A taxa é somada uma única vez por pedido e aparece separada dos produtos no carrinho, WhatsApp e comanda. Atualize index.html, style.css e script.js no site; na automação, atualize receipt.js e core.js.


### Atualização: localização automática e contato no link

Atualize index.html e script.js no site. No programa Windows, atualize app.js, core.js, phone.js, receipt.js e a pasta test. Preserve config.json, a sessão e state.json. Feche e reinicie o programa após copiar.

Para “Enviar para meu local”, bairro e cidade são identificados por GPS e consultas automáticas. O sistema tenta Nominatim/OpenStreetMap, BigDataCloud diretamente no celular e consultas regionais. Não descarta cidade/bairro quando a rua falta e não salva no cache respostas incompletas. Não usa a cidade como se fosse o bairro. Os seletores ficam ocultos nesse fluxo; se os dados forem insuficientes, o cliente pode tentar novamente. Uma região incompleta não recebe taxa por suposição. Nenhum serviço gratuito garante que todos os bairros estejam mapeados. A leitura regional é aproximada, exige o mesmo município e proximidade; o cliente confere o ponto do mapa antes de enviar. A fonte alternativa recebe apenas coordenadas atuais obtidas com autorização no celular, e não usa localização por IP.

A saudação diária mantém a frase escolhida e agora entrega o link do cardápio com ?contato=NUMERO_DO_REMETENTE. Quando o cliente abre ESSE link, o pedido já inclui Contato abaixo de Cliente antes de abrir o WhatsApp. Teste com um celular que ainda não recebeu a saudação no dia, ou no dia seguinte; saudações já enviadas não se repetem. O link público sem identificação não revela ao site o número da conta WhatsApp e portanto não consegue preenchê-lo antes do envio. Um link personalizado é individual; não o use como link público da loja. A automação confirma o contato pelo remetente real no recebimento e o inclui no registro e impressão; não modifica mensagens recebidas no WhatsApp. Se o WhatsApp não disponibilizar o número, não é inventado nem tratado como LID.

Na mensagem e na impressão, o nome Barra do Garças é omitido na seção de entrega. Pontal do Araguaia e Aragarças continuam identificadas. A cidade completa segue nos dados de cobrança para calcular a taxa.

Verificações: captura por fonte alternativa, resposta sem rua, município no campo county, bairro em localityName, cache de falhas, taxa por cidade, número via link e via contato de mensagem/conversa, layout da impressão, saudações diárias e deduplicação. As respostas de mapas e do WhatsApp foram simuladas nos testes. Ainda é necessário testar bairros reais no celular, a conexão por QR Code e a impressão na loja.


### Retirada de ingredientes
Atualize script.js e style.css no site e receipt.js na automação. As etiquetas verdes permitem retirar/recolocar ingredientes incluídos. Vermelho claro indica retirada; o preço base permanece igual. A escolha vale para o tamanho adicionado e é registrada no carrinho, WhatsApp e impressão como “Sem [ingrediente]”. As seleções de retirada são limpas após adicionar. Reinicie a automação após atualizar receipt.js.

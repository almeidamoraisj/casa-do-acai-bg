'use strict';
const {parseReceipt,receiptRows}=require('./receipt');
const recipes=require('./recipes.json');
const normalize=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
function kitchenTickets(record){
 const r=parseReceipt(record),groups=new Map();
 for(const item of r.items){
  const name=item.name.replace(/\s*\([^)]*ml\)\s*$/i,'').trim();
  const recipe=recipes[name];
  if(!recipe)throw new Error('Receita não cadastrada para a cozinha: '+name);
  const removed=[...new Set(item.removed)].sort();
  const included=recipe.filter(x=>!removed.some(y=>normalize(x)===normalize(y)));
  const extras=item.extras.map(x=>x.name).sort();
  const key=JSON.stringify([item.name,included,removed,extras]);
  if(groups.has(key))groups.get(key).qty+=item.qty;
  else groups.set(key,{name:item.name,qty:item.qty,included,removed,extras});
 }
 const date=new Date(record.receivedAt||Date.now());
 const parts=new Intl.DateTimeFormat('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);
 const part=type=>parts.find(p=>p.type===type).value;
 const stamp=part('day')+'/'+part('month')+'/'+part('year')+' - '+part('hour')+':'+part('minute');
 return [...groups.values()].map(item=>{
  const rows=[{cells:['CLIENTE: '+r.client]}, {cells:['Data: '+stamp],space:8},
   {rule:'double'}, {cells:['PRODUTO','QTD'],columns:[.83,.17],noWrap:true}, {rule:'double'},
   {cells:[item.name,'x'+item.qty],columns:[.83,.17],space:2}];
  for(const name of item.removed)rows.push({cells:['Sem '+name],size:.72,indent:14});
  for(const extra of item.extras)rows.push({cells:['1x    '+extra],size:.72,indent:8});
  if(r.note)rows.push({cells:['Obs.: '+r.note],size:.8,space:3});
  rows.push({rule:'double'});
  return rows;
 });
}

async function printOrder(record,{config,save,printLayout}){
 // Prepare tudo antes de imprimir; não envia uma comanda se a receita for desconhecida.
 const jobs=[{id:'receipt',rows:receiptRows(record),printer:config.printerName,font:config.fontSize||9}];
 if(config.kitchenEnabled!==false)kitchenTickets(record).forEach((rows,i)=>jobs.push({id:'kitchen-'+i,rows,printer:config.kitchenPrinterName||config.printerName,font:config.kitchenFontSize||10}));
 record.printJobs ||= {};
 for(const job of jobs){
  if(record.printJobs[job.id]==='submitted')continue;
  record.printJobs[job.id]='printing';save();
  try{await printLayout(job.rows,job.printer,job.font,job.id);record.printJobs[job.id]='submitted';save();}
  catch(error){record.printJobs[job.id]='failed';save();throw error;}
 }
}
module.exports={kitchenTickets,printOrder};

'use strict';
// Eventos de sincronização não são contatos novos iniciados pelo cliente.
class IncomingGate {
 constructor(now=()=>Date.now()){this.now=now;this.stop();this.seen=new Set();}
 start(){this.since=Math.floor(this.now()/1000);this.generation++;}
 stop(){this.since=null;this.generation=(this.generation||0)+1;}
 accept(message){
  if(this.since===null || message.fromMe || message.id?.fromMe || message.isStatus || message.broadcast || !/@(c\.us|lid)$/.test(message.from||''))return false;
  if(!new Set(['chat','image','video','audio','ptt','document','sticker','location','vcard','multi_vcard','buttons_response','list_response']).has(message.type))return false;
  const timestamp=message.timestamp;
  if(!Number.isFinite(timestamp)||timestamp<=this.since||timestamp>Math.floor(this.now()/1000)+60||message.rawData?.isNewMsg===false)return false;
  const id=message.id?._serialized;
  if(!id||this.seen.has(id))return false;
  this.seen.add(id);
  if(this.seen.size>10000)this.seen.delete(this.seen.values().next().value);
  return true;
 }
}
module.exports={IncomingGate};

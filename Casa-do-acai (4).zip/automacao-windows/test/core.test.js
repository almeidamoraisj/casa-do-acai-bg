const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {Store,Handler,dayKey,parseOrder}=require('../core');
const body='Pedido Casa do Açaí BG: BG-12345678\nOlá! Quero fazer um pedido:\n• 1x Marmita Premium — R$ 40,00\nTotal: R$ 40,00\nNome: João\nForma de pagamento: Pix\n📍 *LOCAL DE ENTREGA*\nRua 123';
function setup(){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'acai-test-'));const file=path.join(dir,'state.json');let now=new Date('2026-10-10T15:00:00Z'),sent=[],printed=[];let store=new Store(file);const config={timezone:'America/Sao_Paulo',greetingEnabled:true,greeting:'Boa Tarde'};const opts={store,config,send:async(m,text)=>sent.push([m.from,text]),print:async r=>printed.push(r.id),now:()=>now,log:()=>{}};return {file,store,opts,sent,printed,setDate:d=>now=new Date(d),handler:new Handler(opts)};}
const msg=(body='Olá',from='123@c.us')=>({from,body,type:'chat',id:{_serialized:'message1'}});
test('uma saudação por cliente por dia, mesmo após reinício',async()=>{const x=setup();await x.handler.handle(msg());await x.handler.handle(msg('Oi novamente'));assert.equal(x.sent.length,1);const next=new Handler({...x.opts,store:new Store(x.file)});await next.handle(msg());assert.equal(x.sent.length,1);await next.handle(msg('Oi','456@c.us'));assert.equal(x.sent.length,2);x.setDate('2026-10-11T03:01:00Z');await next.handle(msg());assert.equal(x.sent.length,3);});
test('dia de Brasília atravessa meia-noite UTC corretamente',()=>{assert.equal(dayKey(new Date('2026-10-11T02:59:00Z')),'2026-10-10');});
test('imprime só pedido recebido, deduplicação persistente',async()=>{const x=setup();await x.handler.handle(msg());assert.equal(x.printed.length,0);await x.handler.handle(msg(body));await x.handler.handle(msg(body));assert.equal(x.printed.length,1);const next=new Handler({...x.opts,store:new Store(x.file)});await next.handle(msg(body));assert.equal(x.printed.length,1);assert.equal(Object.values(x.store.data.orders)[0].status,'submitted');});
test('ignora próprias mensagens, grupos e status',async()=>{const x=setup();await x.handler.handle({...msg(body),fromMe:true});await x.handler.handle(msg(body,'123@g.us'));await x.handler.handle(msg(body,'status@broadcast'));assert.equal(x.sent.length,0);assert.equal(x.printed.length,0);});
test('falha de saudação não impede impressão',async()=>{const x=setup();x.handler.send=async()=>{throw Error('offline')};await x.handler.handle(msg(body));await x.handler.handle(msg(body));assert.equal(x.printed.length,1);assert.equal(Object.values(x.store.data.greetings)[0].status,'failed');});
test('falha da impressora fica registrada sem reimprimir silenciosamente',async()=>{const x=setup();let calls=0;x.handler.print=async()=>{calls++;throw Error('USB offline')};await x.handler.handle(msg(body));await x.handler.handle(msg(body));assert.equal(calls,1);assert.equal(Object.values(x.store.data.orders)[0].status,'failed');});
test('mensagem incompleta não é pedido',()=>{assert.equal(parseOrder('Pedido Casa do Açaí BG: BG-12345678\nOlá'),null);assert.equal(parseOrder('Olá! Quero fazer um pedido'),null);});
test('cardápio envia link em toda solicitação nova, mesmo após saudação diária',async()=>{
 const x=setup();await x.handler.handle(msg('Oi'));
 for(const text of ['cardápio','CARDAPIO','Pode mandar o cardápio?'])await x.handler.handle(msg(text));
 assert.equal(x.sent.length,4);
 for(const [,text] of x.sent.slice(1))assert.equal(text,'Aqui está o link do cardápio: https://almeidamoraisj.github.io/casa-do-acai-bg/');
 await x.handler.handle(msg('Boa noite'));assert.equal(x.sent.length,4);assert.equal(x.printed.length,0);
});
test('primeira mensagem pedindo cardápio recebe apenas uma resposta e respeita limites da palavra',async()=>{
 const x=setup();await x.handler.handle(msg('Cardápio!'));assert.equal(x.sent.length,1);
 await x.handler.handle(msg('meucardapio'));assert.equal(x.sent.length,2);assert.doesNotMatch(x.sent[1][1],/Aqui está/);
});
test('comando não responde a grupo ou mensagem própria e não interrompe pedido',async()=>{
 const x=setup();await x.handler.handle({...msg('cardápio'),fromMe:true});await x.handler.handle(msg('cardápio','123@g.us'));assert.equal(x.sent.length,0);
 await x.handler.handle(msg(body+'\nObservação: vi no cardápio'));assert.equal(x.printed.length,1);
 await x.handler.handle(msg(body.replace('BG-12345678','BG-87654321')));assert.equal(x.printed.length,2);
});

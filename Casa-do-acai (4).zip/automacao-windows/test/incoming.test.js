const {test}=require('node:test'),assert=require('node:assert/strict');
const {IncomingGate}=require('../incoming');
function setup(){let now=1700000000000;const gate=new IncomingGate(()=>now);const msg=(extra={})=>({from:'5566999999999@c.us',type:'chat',timestamp:1700000001,id:{_serialized:'new'},...extra});return {gate,msg,advance:()=>now+=2000};}
test('inicialização e histórico não causam resposta; mensagem nova entra',()=>{const {gate,msg,advance}=setup();assert.equal(gate.accept(msg()),false);gate.start();assert.equal(gate.accept(msg({timestamp:1699999999})),false);assert.equal(gate.accept(msg({timestamp:1700000000})),false);advance();assert.equal(gate.accept(msg()),true);assert.equal(gate.accept(msg()),false);});
test('ignora próprios, grupos, status, notificações e mensagens sem horário confiável',()=>{const {gate,msg,advance}=setup();gate.start();advance();for(const change of [{fromMe:true},{from:'123@g.us'},{isStatus:true},{broadcast:true},{type:'notification'},{timestamp:undefined},{timestamp:NaN},{id:undefined}])assert.equal(gate.accept(msg(change)),false);});
test('reconexão descarta mensagens do período offline',()=>{const {gate,msg,advance}=setup();gate.start();advance();gate.stop();assert.equal(gate.accept(msg()),false);gate.start();assert.equal(gate.accept(msg()),false);advance();assert.equal(gate.accept(msg({timestamp:1700000003})),true);});

test('campo interno isNewMsg falso não bloqueia mensagem nova',()=>{const {gate,msg,advance}=setup();gate.start();advance();assert.equal(gate.accept(msg({rawData:{isNewMsg:false}})),true);});
test('horário numérico textual e ready repetido preservam mensagens novas',()=>{const {gate,msg,advance}=setup();gate.start();advance();gate.start();assert.equal(gate.accept(msg({timestamp:'1700000001'})),true);});

const {test}=require('node:test'),assert=require('node:assert/strict');
const {greetingByTime}=require('../core');
const greeting='Boa Tarde, Casa do Açaí BG agradece seu contato, segue o link: https://almeidamoraisj.github.io/casa-do-acai-bg/';
test('saudação muda nas 12h e 18h de Brasília, preservando mensagem e link',()=>{
 for(const [utc,prefix] of [['2026-10-22T02:59:00Z','Boa noite'],['2026-10-22T03:00:00Z','Bom dia'],['2026-10-22T14:59:00Z','Bom dia'],['2026-10-22T15:00:00Z','Boa tarde'],['2026-10-22T20:59:00Z','Boa tarde'],['2026-10-22T21:00:00Z','Boa noite']]){
  const result=greetingByTime(greeting,new Date(utc));assert.equal(result,prefix+', Casa do Açaí BG agradece seu contato, segue o link: https://almeidamoraisj.github.io/casa-do-acai-bg/');
 }
});
test('não duplica saudação existente e aceita texto sem saudação',()=>{
 const date=new Date('2026-10-22T21:00:00Z');
 for(const text of ['BOM DIA! Mensagem','Boa noite, Mensagem','Mensagem'])assert.equal(greetingByTime(text,date),'Boa noite, Mensagem');
});

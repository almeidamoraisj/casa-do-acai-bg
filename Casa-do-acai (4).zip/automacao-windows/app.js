'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const {Store,Handler}=require('./core');
const {IncomingGate}=require('./incoming');
const {printOrder}=require('./kitchen');
const root=__dirname,config=JSON.parse(fs.readFileSync(path.join(root,'config.json'),'utf8'));
const dataDir=path.join(process.env.LOCALAPPDATA||root,'CasaAcaiBG');fs.mkdirSync(dataDir,{recursive:true});
// Apenas um processo pode imprimir/responder com esta sessão.
let lock;
try {lock=fs.openSync(path.join(dataDir,'app.lock'),'wx');fs.writeFileSync(lock,String(process.pid));}
catch {console.error('Programa já aberto ou encerramento inesperado. Confira os processos; se não houver outro programa aberto, remova app.lock em '+dataDir);process.exit(1);}
function unlock(){try{fs.closeSync(lock);fs.unlinkSync(path.join(dataDir,'app.lock'));}catch{}}
process.on('exit',unlock);
const store=new Store(path.join(dataDir,'state.json'));
function printLayout(rows,printerName,fontSize,jobId) {
  if(process.platform!=='win32') return Promise.reject(new Error('A impressão requer Windows.'));
  if(!printerName) return Promise.reject(new Error('Informe printerName no config.json.'));
  const filename=path.join(dataDir,'receipt-'+Date.now()+'.json');
  fs.writeFileSync(filename,JSON.stringify(rows),'utf8');
  return new Promise((resolve,reject)=>{
    const child=spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(root,'print.ps1'),'-LayoutFile',filename,'-PrinterName',printerName,'-PaperWidthMm',String(config.paperWidthMm),'-FontSize',String(fontSize)],{windowsHide:true});
    let errors='';child.stderr.on('data',data=>errors+=data.toString());
    let settled=false;const timer=setTimeout(()=>{child.kill();finish(new Error('Tempo de impressão excedido. Confira a fila antes de reimprimir.'));},60000);
    function finish(error){if(settled)return;settled=true;clearTimeout(timer);try{fs.unlinkSync(filename);}catch{}error?reject(error):resolve();}
    child.on('error',finish);child.on('close',code=>finish(code===0?null:new Error(errors||'PowerShell encerrou com código '+code)));
  });
}
function print(record){return printOrder(record,{config,save:()=>store.save(),printLayout});}
async function main(){
  if(process.argv.includes('--print-test')) {await print({id:'BG-TESTE1234567',phone:'5566999999999',body:'*Casa do Açaí BG*\nPedido: BG-TESTE1234567\n\nCliente: Cliente de teste\n\n*PRODUTOS*\n*2x Marmita Premium — R$ 90,00*\nAdicionais em cada unidade:\n + Creme de Ninho · R$ 5,00\n\n*TOTAL: R$ 90,00*\nForma de pagamento: Pix\n📍 *LOCAL DE ENTREGA*\nEndereço: Rua de exemplo, 123',sender:'TESTE',receivedAt:new Date().toISOString()});return;}
  if(process.argv.includes('--list')) {for(const item of Object.values(store.data.orders))console.log(item.id,item.status,item.receivedAt);return;}
  const retryIndex=process.argv.indexOf('--retry');
  if(retryIndex>=0){const id=process.argv[retryIndex+1];const records=Object.values(store.data.orders).filter(r=>r.id===id);if(records.length!==1)throw new Error('Pedido inexistente ou código ambíguo.');const item=records[0];if(item.status==='submitted')throw new Error('Pedido já enviado à impressora. Não reimprimido.');item.status='printing';store.save();try{await print(item);item.status='submitted';delete item.error;}catch(error){item.status='failed';item.error=error.message;throw error;}finally{store.save();}return;}
  const {Client,LocalAuth}=require('whatsapp-web.js'),qrcode=require('qrcode-terminal');
  const client=new Client({authStrategy:new LocalAuth({dataPath:path.join(dataDir,'session')}),puppeteer:{headless:true}});
  let queue=Promise.resolve();
  const incoming=new IncomingGate();
  const handler=new Handler({store,config,send:(message,text)=>message.reply(text),print,
    resolvePhone:message=>require('./phone').resolvePhone(client,message)});
  client.on('qr',qr=>{console.log('WhatsApp Business > Aparelhos conectados > Conectar aparelho. Escaneie:');qrcode.generate(qr,{small:true});});
  client.on('ready',()=>{incoming.start();console.log('Conectado. Somente mensagens novas a partir de agora. Impressora: '+(config.printerName||'NAO CONFIGURADA'));});
  client.on('auth_failure',()=>console.error('Falha na autenticação. Reconecte a sessão.'));
  client.on('disconnected',reason=>{incoming.stop();console.error('WhatsApp desconectado: '+reason+'. Reinicie o programa para reconectar.');});
  client.on('message',message=>{
    if(!incoming.accept(message)){console.log('Mensagem ignorada: '+incoming.reason);return;}
    console.log('Nova mensagem recebida. Verificando cardápio, saudação e pedido.');
    const generation=incoming.generation;
    queue=queue.then(()=>{if(incoming.since!==null&&incoming.generation===generation)return handler.handle(message);}).catch(error=>console.error('Falha: '+error.message));
  });
  process.on('SIGINT',async()=>{console.log('Encerrando...');await queue;await client.destroy();process.exit(0);});
  await client.initialize();
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});

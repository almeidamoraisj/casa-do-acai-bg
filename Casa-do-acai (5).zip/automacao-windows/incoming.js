'use strict';
const {createHash}=require('node:crypto');
function messageKey(message,timestamp) {
  for(const candidate of [message.id,message.rawData?.id,message._data?.id]) {
    const id=typeof candidate==='string'?candidate:candidate?._serialized || candidate?.id;
    if(typeof id==='string' && id.trim())return JSON.stringify([message.from,id]);
  }
  // Fallback local de deduplicação, nunca usado como ID do WhatsApp nem registrado no log.
  return 'local:'+createHash('sha256').update(JSON.stringify([message.from,timestamp,message.type,message.body||'',message.mediaKey||'',message.location||null,message.vCards||null])).digest('hex');
}
// Eventos de sincronização não são contatos novos iniciados pelo cliente.
class IncomingGate {
 constructor(now=()=>Date.now()){this.now=now;this.stop();this.seen=new Set();}
 start(){if(this.since===null){this.since=Math.floor(this.now()/1000);this.generation++;}}
 stop(){this.since=null;this.generation=(this.generation||0)+1;}
 reject(reason){this.reason=reason;return false;}
 accept(message){
  this.reason=null;
  if(this.since===null)return this.reject('ainda não conectado');
  if(message.fromMe || message.id?.fromMe)return this.reject('mensagem do próprio número');
  if(message.isStatus || message.broadcast || !/@(c\.us|lid)$/.test(message.from||''))return this.reject('grupo, status ou destinatário não individual');
  if(!new Set(['chat','image','video','audio','ptt','document','sticker','location','vcard','multi_vcard','buttons_response','list_response']).has(message.type))return this.reject('tipo de evento não atendido');
  const timestamp=typeof message.timestamp==='string' && message.timestamp.trim() ? Number(message.timestamp) : message.timestamp;
  if(!Number.isFinite(timestamp))return this.reject('horário da mensagem ausente');
  if(timestamp<=this.since)return this.reject('mensagem anterior à conexão; se acabou de enviar, confira o relógio do Windows');
  if(timestamp>Math.floor(this.now()/1000)+60)return this.reject('horário futuro; sincronize o relógio do Windows');
  // isNewMsg é um campo interno mutável, não um indicador confiável de histórico.
  const id=messageKey(message,timestamp);
  if(this.seen.has(id))return this.reject('evento repetido');
  this.seen.add(id);
  if(this.seen.size>10000)this.seen.delete(this.seen.values().next().value);
  return true;
 }
}
module.exports={IncomingGate,messageKey};
